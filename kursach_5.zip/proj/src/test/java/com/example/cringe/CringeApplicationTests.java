package com.example.cringe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CringeApplicationTests {

	@Test
	void contextLoads() {
	}

}
