package com.example.cringe.util;

public enum Role {
    USER;
}
