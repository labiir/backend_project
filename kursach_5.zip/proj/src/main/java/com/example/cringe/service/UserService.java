package com.example.cringe.service;

import com.example.cringe.model.UserWater;
import com.example.cringe.util.Role;
import com.example.cringe.model.User;
import com.example.cringe.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UsersRepository usersRepository;
    public User getUserByUsername(String username) {
        return usersRepository.findByUsername(username);
    }
    public List<User> getUsers() {
        return usersRepository.findAll();
    }
    public User getUserById(Long id) {
        return usersRepository.findById(id).orElseThrow(() ->new RuntimeException("User with this ID = " + id +" not found"));
    }
    public void saveUser(User user) {
        usersRepository.save(user);
    }
    public void updateUser(User user) {
        User existingUser = usersRepository.findById(user.getId()).orElse(null);
        if (existingUser != null) {
            existingUser.setEmail(user.getEmail());
            existingUser.setLastName(user.getLastName());
            existingUser.setName(user.getName());
            existingUser.setAdress(user.getAdress());
            usersRepository.save(existingUser);
        }
    }
    public void registerUser(User user) {
        user.setRoles(Collections.singleton(Role.USER));
        user.setActive(true);
        usersRepository.save(user);
    }
}
