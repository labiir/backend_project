package com.example.cringe.controller;

import com.example.cringe.model.User;
import com.example.cringe.model.UserElectricity;
import com.example.cringe.model.UserGas;
import com.example.cringe.model.UserWater;
import com.example.cringe.service.UserElectricityService;
import com.example.cringe.service.UserGasService;
import com.example.cringe.service.UserService;
import com.example.cringe.service.UserWaterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.List;

@Controller
public class HelloController {
    @Autowired
    private UserService userService;
    @Autowired
    private UserWaterService userWaterService;
    @Autowired
    private UserGasService userGasService;
    @Autowired
    private UserElectricityService userElectricityService;
    @GetMapping("/hello")
    public String hello(Model model) {
        model.addAttribute("title", "Таблиці");
        List<UserWater> userWaterList = userWaterService.getUserWaters();
        model.addAttribute("userWaterList", userWaterList);
        List<UserGas> userGasList = userGasService.getUserGases();
        model.addAttribute("userGasList", userGasList);
        List<UserElectricity> userElectricityList = userElectricityService.getUserElecs();
        model.addAttribute("userElectricityList", userElectricityList);
        return "hello";
    }
    @GetMapping("/gas/edit/{id}")
    @PreAuthorize("#id == authentication.principal.id")
    public String editGas(Model model, Principal principal) {
        String username = principal.getName();
        UserGas userGas  = userGasService.getUserGasByUsername(username);
        model.addAttribute("userGas", userGas);
        return "edit_gas";
    }

    @PostMapping("/gas/save")
    public String saveGas(@ModelAttribute("userGas") UserGas userGas) {
        if (userGas.getId() == null) {
            userGasService.saveUserGas(userGas);
        } else {
            userGasService.updateUserGas(userGas);
        }
        return "redirect:/hello";
    }

    @GetMapping("/water/edit/{id}")
    @PreAuthorize("#id == authentication.principal.id")
    public String editWater(Model model, Principal principal) {
        String username = principal.getName();
        UserWater userWater  = userWaterService.getUserWaterByUsername(username);
        model.addAttribute("userWater", userWater);
        return "edit_water";
    }

    @PostMapping("/water/save")
    public String saveWater(@ModelAttribute("userWater") UserWater userWater) {
        userWaterService.updateUserWater(userWater);
        return "redirect:/hello";
    }

    @GetMapping("/electricity/edit/{id}")
    @PreAuthorize("#id == authentication.principal.id")
    public String editElectricity(Model model, Principal principal) {
        String username = principal.getName();
        UserElectricity userElectricity  = userElectricityService.getUserElectricityByUsername(username);
        model.addAttribute("userElectricity", userElectricity);
        return "edit_electricity";
    }

    @PostMapping("/electricity/save")
    public String saveElectricity(@ModelAttribute("userElectricity") UserElectricity userElectricity) {
        if (userElectricity.getId() == null) {
            userElectricityService.saveUserElectricity(userElectricity);
        } else {
            userElectricityService.updateUserElectricity(userElectricity);
        }
        return "redirect:/hello";
    }
}
