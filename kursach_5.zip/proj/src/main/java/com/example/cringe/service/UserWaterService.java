package com.example.cringe.service;

import com.example.cringe.model.User;
import com.example.cringe.model.UserElectricity;
import com.example.cringe.model.UserGas;
import com.example.cringe.model.UserWater;
import com.example.cringe.repository.UsersRepository;
import com.example.cringe.repository.UsersWaterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class UserWaterService {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private UsersWaterRepository usersWaterRepository;
    public UserWater getUserWaterByUsername(String username) {
        return usersWaterRepository.findByUsername(username);
    }
    public List<UserWater> getUserWaters() {
        transferData();
        return usersWaterRepository.findAll();
    }
    public void saveUserWater(UserWater userWater) {
        usersWaterRepository.save(userWater);
    }
    public UserWater getUserWaterById(Long id) {
        return usersWaterRepository.findById(id).orElse(null);
    }
    public void updateUserWater(UserWater userWater) {
        UserWater existingUserWater = usersWaterRepository.findById(userWater.getId()).orElse(null);
        if (existingUserWater != null) {
            existingUserWater.setWaterAmount(userWater.getWaterAmount());
            existingUserWater.setSum(userWater.getSum());
            existingUserWater.setInvoiceDate(userWater.getInvoiceDate());
            existingUserWater.setPaymentDate(userWater.getPaymentDate());
            usersWaterRepository.save(existingUserWater);
        }
    }

    public void transferData() {
        List<User> users = usersRepository.findAll();
        for (User user : users) {
            UserWater userWater = usersWaterRepository.findByUsername(user.getUsername());
            if (userWater == null) {
                userWater = new UserWater();
                userWater.setUsername(user.getUsername());
            }
            if (userWater.isTransfered()){
                continue;
            }
            userWater.setWaterAmount(0.0);
            userWater.setSum(0.0);
            userWater.setName(user.getName());
            userWater.setLastName(user.getLastName());
            userWater.setTransfered(true);
            usersWaterRepository.save(userWater);
        }
    }
}