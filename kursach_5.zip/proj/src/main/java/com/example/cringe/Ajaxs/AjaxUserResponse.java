package com.example.cringe.Ajaxs;

import com.example.cringe.model.User;

public class AjaxUserResponse {
    private User user;
    public AjaxUserResponse(User user) {

        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
