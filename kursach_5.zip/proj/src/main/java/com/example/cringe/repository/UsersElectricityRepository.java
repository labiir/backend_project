package com.example.cringe.repository;

import com.example.cringe.model.UserElectricity;
import com.example.cringe.model.UserGas;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsersElectricityRepository extends JpaRepository<UserElectricity, Long> {
    UserElectricity findByUsername(String username);

    Optional<UserElectricity> findById(Long id);

    List<UserElectricity> findAll();
}
