package com.example.cringe.controller;

import com.example.cringe.model.User;
import com.example.cringe.model.UserElectricity;
import com.example.cringe.model.UserGas;
import com.example.cringe.model.UserWater;
import com.example.cringe.service.UserElectricityService;
import com.example.cringe.service.UserGasService;
import com.example.cringe.service.UserService;
import com.example.cringe.service.UserWaterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.List;

@Controller
public class MainController {

    @Autowired
    private UserService userService;
    @Autowired
    private UserWaterService userWaterService;
    @Autowired
    private UserGasService userGasService;
    @Autowired
    private UserElectricityService userElectricityService;


    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("title", "Перехід");
        return "home";
    }
    @GetMapping("/office/{id}")
    @PreAuthorize("#id == authentication.principal.id")
    public String office(Principal principal, Model model) {
        String username = principal.getName();
        User user = userService.getUserByUsername(username);
        model.addAttribute("user", user);
        model.addAttribute("Name", user.getName());
        model.addAttribute("lastName", user.getLastName());
        model.addAttribute("Email", user.getEmail());
        model.addAttribute("id", user.getId());
        model.addAttribute("adress", user.getAdress());

        return "office";
    }
    @GetMapping("/user/edit/{id}")
    @PreAuthorize("#id == authentication.principal.id")
    public String editUser(Model model, Principal principal) {
        String username = principal.getName();
        User user = userService.getUserByUsername(username);
        model.addAttribute("user", user);
        return "edit_user";
    }

    @PostMapping("/user/save/{id}")
    public String saveOldUser(@ModelAttribute("user") User user) {
        userService.updateUser(user);
        return "redirect:/office/{id}";
    }
    @GetMapping("/help")
    public String showHelp() {
        return "help";
    }

    @GetMapping("/faq")
    public String showFaq() {
        return "faq";
    }
}
