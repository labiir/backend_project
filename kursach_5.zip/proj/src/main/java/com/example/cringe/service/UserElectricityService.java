package com.example.cringe.service;

import com.example.cringe.model.User;
import com.example.cringe.model.UserElectricity;
import com.example.cringe.model.UserGas;
import com.example.cringe.model.UserWater;
import com.example.cringe.repository.UsersElectricityRepository;
import com.example.cringe.repository.UsersGasRepository;
import com.example.cringe.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserElectricityService {
    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private UsersElectricityRepository usersElectricityRepository;
    public UserElectricity getUserElectricityByUsername(String username) {
        return usersElectricityRepository.findByUsername(username);
    }
    public List<UserElectricity> getUserElecs() {
        transferData();
        return usersElectricityRepository.findAll();
    }
    public void saveUserElectricity(UserElectricity userElectricity) {
        usersElectricityRepository.save(userElectricity);
    }
    public UserElectricity getUserElectricityById(Long id) {
        return usersElectricityRepository.findById(id).orElse(null);
    }
    public void updateUserElectricity(UserElectricity userElectricity) {
        UserElectricity existingUserElectricity = usersElectricityRepository.findById(userElectricity.getId()).orElse(null);
        if (existingUserElectricity != null) {
            existingUserElectricity.setElectricityAmount(userElectricity.getElectricityAmount());
            existingUserElectricity.setSum(userElectricity.getSum());
            existingUserElectricity.setInvoiceDate(userElectricity.getInvoiceDate());
            existingUserElectricity.setPaymentDate(userElectricity.getPaymentDate());
            usersElectricityRepository.save(existingUserElectricity);
        }
    }
    public void transferData() {
        List<User> users = usersRepository.findAll();
        for (User user : users) {
            UserElectricity userElectricity = usersElectricityRepository.findByUsername(user.getUsername());
            if (userElectricity == null) {
                userElectricity = new UserElectricity();
                userElectricity.setUsername(user.getUsername());
            }
            if (userElectricity.isTransfered()){
                continue;
            }
            userElectricity.setElectricityAmount(0.0);
            userElectricity.setSum(0.0);
            userElectricity.setName(user.getName());
            userElectricity.setLastName(user.getLastName());
            userElectricity.setTransfered(true);
            usersElectricityRepository.save(userElectricity);
        }
    }
}
