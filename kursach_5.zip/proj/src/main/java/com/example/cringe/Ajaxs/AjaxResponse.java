package com.example.cringe.Ajaxs;

import com.example.cringe.model.UserGas;

public class AjaxResponse {
    private UserGas userGas;
    public AjaxResponse(UserGas userGas) {

        this.userGas = userGas;
    }

    public UserGas getUserGas() {
        return userGas;
    }

    public void setUserGas(UserGas userGas) {
        this.userGas = userGas;
    }
}
