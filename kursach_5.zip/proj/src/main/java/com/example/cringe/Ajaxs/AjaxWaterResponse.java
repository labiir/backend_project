package com.example.cringe.Ajaxs;

import com.example.cringe.model.UserWater;

public class AjaxWaterResponse {
    private UserWater userWater;
    public AjaxWaterResponse(UserWater userWater) {

        this.userWater = userWater;
    }

    public UserWater getUserWater() {
        return userWater;
    }

    public void setUserWater(UserWater userWater) {
        this.userWater = userWater;
    }
}
