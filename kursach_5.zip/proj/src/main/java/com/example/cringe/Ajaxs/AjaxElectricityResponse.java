package com.example.cringe.Ajaxs;

import com.example.cringe.model.UserElectricity;

public class AjaxElectricityResponse {
    private UserElectricity userElectricity;
    public AjaxElectricityResponse(UserElectricity userElectricity) {

        this.userElectricity = userElectricity;
    }

    public UserElectricity getUserElectricity() {
        return userElectricity;
    }

    public void setUserElectricity(UserElectricity userElectricity) {
        this.userElectricity = userElectricity;
    }
}
