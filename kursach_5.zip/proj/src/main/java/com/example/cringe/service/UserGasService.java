package com.example.cringe.service;

import com.example.cringe.model.User;
import com.example.cringe.model.UserElectricity;
import com.example.cringe.model.UserGas;
import com.example.cringe.model.UserWater;
import com.example.cringe.repository.UsersGasRepository;
import com.example.cringe.repository.UsersRepository;
import com.example.cringe.repository.UsersWaterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserGasService {
    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private UsersGasRepository usersGasRepository;
    public UserGas getUserGasByUsername(String username) {
        return usersGasRepository.findByUsername(username);
    }
    public List<UserGas> getUserGases() {
        transferData();
        return usersGasRepository.findAll();
    }
    public void saveUserGas(UserGas userGas) {
        usersGasRepository.save(userGas);
    }
    public UserGas getUserGasById(Long id) {
        return usersGasRepository.findById(id).orElse(null);
    }
    public void updateUserGas(UserGas userGas) {
        UserGas existingUserGas = usersGasRepository.findById(userGas.getId()).orElse(null);
        if (existingUserGas != null) {
            existingUserGas.setGasAmount(userGas.getGasAmount());
            existingUserGas.setSum(userGas.getSum());
            existingUserGas.setInvoiceDate(userGas.getInvoiceDate());
            existingUserGas.setPaymentDate(userGas.getPaymentDate());
            usersGasRepository.save(existingUserGas);
        }
    }
    public void transferData() {
        List<User> users = usersRepository.findAll();
        for (User user : users) {
            UserGas userGas = usersGasRepository.findByUsername(user.getUsername());
            if (userGas == null) {
                userGas = new UserGas();
                userGas.setUsername(user.getUsername());
            }
            if (userGas.isTransfered()){
                continue;
            }
            userGas.setGasAmount(0.0);
            userGas.setSum(0.0);
            userGas.setName(user.getName());
            userGas.setLastName(user.getLastName());
            userGas.setTransfered(true);
            usersGasRepository.save(userGas);
        }
    }
}
