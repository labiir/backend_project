$(document).on('click', '.edit-link', function(event) {
  event.preventDefault(); // предотвратить стандартное поведение ссылки
  var url = $(this).attr('href'); // получить URL для отправки AJAX запроса
  var id = parseInt(url.substring(url.lastIndexOf('/') + 1)); // получить идентификатор пользователя из URL и преобразовать в число
  // отправить AJAX запрос для получения данных пользователя
  $.get('/userGas/' + id, function(userGas) {
    // установить значения в поля ввода модального окна
    $('#id').val(userGas.id);
    $('#name').val(userGas.name);
    $('#lastName').val(userGas.lastName);
    $('#gasAmount').val(userGas.gasAmount);
    $('#sum').val(userGas.sum);
    $('#invoiceDate').val(userGas.invoiceDate);
    $('#paymentDate').val(userGas.paymentDate);
    // открыть модальное окно
    $('#editModal').modal('show');
  });
});
