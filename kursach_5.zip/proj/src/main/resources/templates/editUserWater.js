$(document).on('click', '.edit-link', function(event) {
  event.preventDefault(); // предотвратить стандартное поведение ссылки
  var url = $(this).attr('href'); // получить URL для отправки AJAX запроса
  var id = parseInt(url.substring(url.lastIndexOf('/') + 1)); // получить идентификатор пользователя из URL и преобразовать в число
  // отправить AJAX запрос для получения данных пользователя
  $.get('/userWater/' + id, function(userWater) {
    // установить значения в поля ввода модального окна
    $('#id').val(userWater.id);
    $('#name').val(userWater.name);
    $('#lastName').val(userWater.lastName);
    $('#waterAmount').val(userWater.waterAmount);
    $('#sum').val(userWater.sum);
    $('#invoiceDate').val(userWater.invoiceDate);
    $('#paymentDate').val(userWater.paymentDate);
    // открыть модальное окно
    $('#editModal').modal('show');
  });
});