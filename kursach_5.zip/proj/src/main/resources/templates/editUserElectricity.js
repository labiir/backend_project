$(document).on('click', '.edit-link', function(event) {
  event.preventDefault(); // предотвратить стандартное поведение ссылки
  var url = $(this).attr('href'); // получить URL для отправки AJAX запроса
  var id = parseInt(url.substring(url.lastIndexOf('/') + 1)); // получить идентификатор пользователя из URL и преобразовать в число
  // отправить AJAX запрос для получения данных пользователя
  $.get('/userElectricity/' + id, function(userElectricity) {
    // установить значения в поля ввода модального окна
    $('#id').val(userElectricity.id);
    $('#name').val(userElectricity.name);
    $('#lastName').val(userElectricity.lastName);
    $('#electricityAmount').val(userElectricity.electricityAmount);
    $('#sum').val(userElectricity.sum);
    $('#invoiceDate').val(userElectricity.invoiceDate);
    $('#paymentDate').val(userElectricity.paymentDate);
    // открыть модальное окно
    $('#editModal').modal('show');
  });
});