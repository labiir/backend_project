$(document).on('click', '.edit-link', function(event) {
  event.preventDefault(); // предотвратить стандартное поведение ссылки
  var url = $(this).attr('href'); // получить URL для отправки AJAX запроса
  var id = parseInt(url.substring(url.lastIndexOf('/') + 1)); // получить идентификатор пользователя из URL и преобразовать в число
  // отправить AJAX запрос для получения данных пользователя
  $.get('/user/' + id, function(user) {
    // установить значения в поля ввода модального окна
    $('#id').val(user.id);
    $('#name').val(user.name);
    $('#lastName').val(user.lastName);
    $('#Email').val(user.email);
    $('#adress').val(user.adress);
    // открыть модальное окно
    $('#editModal').modal('show');
  });
});
